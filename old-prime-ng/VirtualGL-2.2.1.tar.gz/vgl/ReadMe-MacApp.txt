The Mac VirtualGL Client is a Unix application which must be executed
inside the Mac X11 environment.  To do this,

-- Install the Mac X11 Application (this application is not installed by
default but is available on the OS X installation discs.)

-- Start the X11 application (in Applications->Utilities)

-- Start a new xterm (Command-N) if one isn't started already

-- In the xterm window, you can now use the VirtualGL client applications
as described in the VirtualGL documentation.
